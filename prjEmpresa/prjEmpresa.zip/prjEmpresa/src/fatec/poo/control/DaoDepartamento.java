/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fatec.poo.control;

import fatec.poo.model.Departamento;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author 0030482321020
 */
public class DaoDepartamento {
     private Connection conn;

    public DaoDepartamento(Connection conn) {
        this.conn = conn;
    }
     
     public Departamento consultar (String sigla, String nome) {
        Departamento objDep = null;         
       
        PreparedStatement ps;
        try {
            ps = conn.prepareStatement("SELECT * from tblDepartamento where Sigla_Dep = ? AND Nome_Dep = ?");
            
            ps.setString(1, sigla);
            ps.setString(2, nome);
            ResultSet rs = ps.executeQuery();
           
            if (rs.next() == true) {
                objDep = new Departamento(rs.getString("Sigla_Dep"),rs.getString("Nome_Dep"));
            }
        }
        catch (SQLException ex) { 
             System.out.println(ex.toString());   
        }
        return(objDep);
    } 
     
     public void inserir(Departamento objDep) {
        PreparedStatement ps;
        try {
            ps = conn.prepareStatement("INSERT INTO tblDepartamento (Sigla_Dep, Nome_Dep) VALUES (?, ?)");
            ps.setString(1, objDep.getSigla());
            ps.setString(2, objDep.getNome());

            ps.execute(); // Envia a instrução SQL para o SGBD
        } catch (SQLException ex) {
            System.out.println("Erro ao inserir departamento: " + ex.toString());
            }
        }

     
     public void alterar(Departamento objDep) {
        PreparedStatement ps;
        try {
            ps = conn.prepareStatement("UPDATE tblDepartamento SET Nome_Dep = ? WHERE Sigla_Dep = ?");
            ps.setString(1, objDep.getNome());
            ps.setString(2, objDep.getSigla());

            ps.execute(); // Envia a instrução SQL para o SGBD
        } catch (SQLException ex) {
            System.out.println("Erro ao alterar departamento: " + ex.toString());
        }
    }

     
     public void excluir(Departamento objDep) {
        PreparedStatement ps;
        try {
            ps = conn.prepareStatement("DELETE FROM tblDepartamento WHERE Sigla_Dep = ?");
            ps.setString(1, objDep.getSigla());

            ps.execute(); // Envia a instrução SQL para o SGBD
        } catch (SQLException ex) {
            System.out.println("Erro ao excluir departamento: " + ex.toString());
        }
    }

}
