package fatec.poo.model;

import java.util.ArrayList;

/**
 *
 * @author João Pedro G. e Miguel Delgado
 */
public class Hospede extends Pessoa {
    private String cpf;
    private double taxaDesconto;
    private ArrayList<Registro> registro;

    public Hospede(String cpf, String nome) {
        super(nome);
        this.cpf = cpf;
        registro = new ArrayList<Registro>();
    }

    public void setTaxaDesconto(double taxaDesconto) {
        this.taxaDesconto = taxaDesconto;
    }

    public String getCpf() {
        return cpf;
    }

    public double getTaxaDesconto() {
        return taxaDesconto;
    }
    
    public void addRegistro(Registro registro){
        this.registro.add(registro);
    }
    
}
