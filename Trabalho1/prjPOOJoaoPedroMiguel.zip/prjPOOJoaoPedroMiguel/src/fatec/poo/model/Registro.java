package fatec.poo.model;

import java.time.LocalDate;
import java.util.ArrayList;

/**
 *
 * @author João Pedro G. e Miguel Delgado
 */
public class Registro {
    private int codigo;
    private LocalDate dataEntrada;
    private LocalDate dataSaida;
    private double valorHospedagem;
    private Recepcionista recepcionista;
    private Hospede hospede;
    private Quarto quarto;
    private ArrayList<ServicoQuarto> servicoQuarto;

    public Registro(int codigo, LocalDate dataEntrada, Recepcionista recepcionista) {
        this.codigo = codigo;
        this.dataEntrada = dataEntrada;
        this.recepcionista = recepcionista;
        servicoQuarto = new ArrayList<ServicoQuarto>();
    }

    public void setDataSaida(LocalDate dataSaida) {
        this.dataSaida = dataSaida;
    }

    public int getCodigo() {
        return codigo;
    }

    public LocalDate getDataEntrada() {
        return dataEntrada;
    }

    public LocalDate getDataSaida() {
        return dataSaida;
    }

    public double getValorHospedagem() {
        return valorHospedagem;
    }
    
    public void addServicoQuarto(ServicoQuarto servicoQuarto){
        this.servicoQuarto.add(servicoQuarto);   
    }
    
    public void reservarQuarto(Hospede hospede, Quarto quarto){
        this.quarto = quarto;
        this.hospede = hospede;
        this.quarto.reservar();
    }
    
    public double liberarQuarto(){
        double totalSQ = 0;
        for (int i = 0; i < servicoQuarto.size(); i++) {
            totalSQ += servicoQuarto.get(i).getValor();
        }
        int dias = (int) (dataSaida.toEpochDay() - dataEntrada.toEpochDay());
        valorHospedagem = (quarto.liberar(dias) * (1 - hospede.getTaxaDesconto()/100)) + totalSQ;
        return valorHospedagem; 
    }
}
