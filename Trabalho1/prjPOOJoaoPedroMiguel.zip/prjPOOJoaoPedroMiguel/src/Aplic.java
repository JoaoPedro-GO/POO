import fatec.poo.model.*;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.Month;
import java.util.Scanner;

/**
 *
 * @author João Pedro G. e Miguel Delgado
 */
public class Aplic {
    public static void main(String[] args) {
        
        DecimalFormat df = new DecimalFormat("R$ #,##0.00");
        
        // Recepcionistas
        Recepcionista rMafinta = new Recepcionista(1010, "Mafinta");
        rMafinta.setTurno("M");
        Recepcionista rMafinto = new Recepcionista(2020, "Mafinto");
        rMafinto.setTurno("N");
        
        // Quartos
        Quarto quarto1 = new Quarto(1, "S", 150);
        Quarto quarto2 = new Quarto(2, "D", 150);
        
        // Serviços de quarto
        ServicoQuarto svqAlmoco = new ServicoQuarto(101, "Almoço");
        svqAlmoco.setValor(80);
        ServicoQuarto svqJanta = new ServicoQuarto(102, "Janta");
        svqJanta.setValor(90);
        ServicoQuarto svqLavanderia = new ServicoQuarto(201, "Lavanderia"); 
        svqLavanderia.setValor(50);
        
       // Hospedes 
       Hospede hospede1 = new Hospede("123.456.789-01", "Murilo da bosch");
       // Setando desconto para o hospede 1
       hospede1.setTaxaDesconto(10);
       Hospede hospede2 = new Hospede("123.456.789-02", "Thales Carro Ligado");
       
       // Fazendo os registros
       Registro registro1 = new Registro(1001, LocalDate.of(2025, 5, 20), rMafinta);
       Registro registro2 = new Registro(1002, LocalDate.of(2025, 5, 20), rMafinto);
       // Verificando se o quarto 1 está disponível 
       System.out.println("Quarto está: " + (quarto1.getSituacao() ? "Indisponível" : "Disponível"));
       // Verificando se o quarto 2 está disponível 
       System.out.println("Quarto está: " + (quarto2.getSituacao() ? "Indisponível" : "Disponível"));
       // Reservando o quarto para o 1° hospede
       registro1.reservarQuarto(hospede1, quarto2);
       // Reservando o quarto para o 2° hospede
       registro2.reservarQuarto(hospede2, quarto1);
       
       // Hospede (1) utilizando serviço de quarto 
      registro1.addServicoQuarto(svqJanta);
       
       // Hospede (2) utilizando serviço de quarto 
       registro2.addServicoQuarto(svqAlmoco);
       
       // Saída dos hospedes
       registro1.setDataSaida(LocalDate.of(2025, 05, 23));
       double totalAPagar1 = registro1.liberarQuarto();
       registro2.setDataSaida(LocalDate.of(2025, 05, 23));
       double totalAPagar2 = registro2.liberarQuarto();

       // Resultados
        System.out.println("=== RESUMO DA HOSPEDAGEM ===");
        System.out.println("Hóspede: " + hospede1.getNome() + " (CPF: " + hospede1.getCpf() + ")");
        System.out.println("Quarto " + quarto2.getNumero() + " - Tipo: " + quarto2.getTipo());
        System.out.println("Recepcionista: " + rMafinta.getNome() + " (Registro Funcional: " + rMafinta.getRegFunc() + ")");
        System.out.println("Data entrada: " + registro1.getDataEntrada());
        System.out.println("Data saída  : " + registro1.getDataSaida());

        System.out.println("TOTAL A PAGAR: " + df.format(totalAPagar1));
        System.out.println("Quarto " + quarto2.getNumero() + " agora está: " + (quarto2.getSituacao() ? "Indisponível" : "Disponível"));
        
        System.out.println("\n\n=== RESUMO DA HOSPEDAGEM ===");
        System.out.println("Hóspede: " + hospede2.getNome() + " (CPF: " + hospede2.getCpf() + ")");
        System.out.println("Quarto " + quarto1.getNumero() + " - Tipo: " + quarto1.getTipo());
        System.out.println("Recepcionista: " + rMafinto.getNome() + " (Registro Funcional: " + rMafinto.getRegFunc() + ")");
        System.out.println("Data entrada: " + registro2.getDataEntrada());
        System.out.println("Data saída  : " + registro2.getDataSaida());
        
        System.out.println("TOTAL A PAGAR: " + df.format(totalAPagar2));
        System.out.println("Quarto " + quarto1.getNumero() + " agora está: " + (quarto1.getSituacao() ? "Indisponível" : "Disponível"));

    }
}  