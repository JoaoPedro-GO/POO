package fatec.poo.model;
/**
 *
 * @author 0030482321020
 */
public class Departamento {
    private String sigla;
    private String nome;
    private Funcionario[] funcionarios;
    private int numFunc;

    public Departamento(String sigla, String nome) {
        this.sigla = sigla; 
        this.nome = nome;
        funcionarios = new Funcionario[5];
        numFunc = 0;
        
    }

    public String getSigla() {
        return sigla;
    }

    public String getNome() {
        return nome;
    }

    public void setSigla(String sigla) {
        this.sigla = sigla;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
     
    public void addFuncionario(Funcionario f){
        funcionarios[numFunc++] = f;
    }
    
    public void listarFuncionario(){
        
    }
}
