package fatec.poo.model;
/**
 *
 * @author 0030482321020
 */
public class FuncionarioMensalista extends Funcionario {
    private double valSalMin;
    private double numSalMin;
    
    public FuncionarioMensalista (int r, String n, String dtAdm, String c, double vsm){
        super(r, n, dtAdm, c);
        
        valSalMin = vsm;
    }
    
    public void setNumSalMin (double n){
        numSalMin = n;
    }
    
    public double calcSalBruto(){
        return (valSalMin * numSalMin);
    }
    
    public double calcSalLiquido(){
        return (calcSalBruto() - calcDesconto());
    }
}
