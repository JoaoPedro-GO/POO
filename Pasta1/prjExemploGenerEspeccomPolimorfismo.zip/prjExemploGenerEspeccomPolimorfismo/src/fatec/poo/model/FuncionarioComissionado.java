package fatec.poo.model;
/**
 *
 * @author 0030482321020
 */
public class FuncionarioComissionado extends Funcionario{
    double salBase;
    double taxaComissao;
    double totalVendas;
    
    public FuncionarioComissionado(int r, String n, String dtAdm, String c, double txComi){
        super(r, n, dtAdm, c);
        taxaComissao = (txComi/100);
    }
    
    public void setSalBase(double s){
        salBase = s;
    }
    
    public double getSalBase(){
        return (salBase);
    }
    
    public double getTotalVendas(){
        return (totalVendas);
    }
    
    public double getTaxaComissao(){
        return (taxaComissao);
    }
    
    public void addVendas(double qtde){
        totalVendas += qtde;
    }
    
    public double calcSalBruto(){
        return (salBase + (taxaComissao * totalVendas));
    }
    
    public double calcGratificacao(){
        if(totalVendas > 5000 && totalVendas < 10000){
            return (calcSalBruto() + (calcSalBruto() * 0.03));
        }
        else {
            if (totalVendas >= 10000){
                return (calcSalBruto() + (calcSalBruto() * 0.05));
                }
        }
        return 0;
    }
    
    public double calcSalLiquido(){
        return (calcSalBruto() - calcDesconto() + calcGratificacao());
    }
}
