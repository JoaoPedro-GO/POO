import fatec.poo.model.FuncionarioHorista;
import fatec.poo.model.FuncionarioMensalista;
import java.text.DecimalFormat;

/**
 *
 * @author 0030482321020
 */
public class Aplic {
    public static void main(String[] args) {
        //Aqui está o código corrigido como você pediu
        DecimalFormat df = new DecimalFormat("#,##0.00");
        FuncionarioHorista funcHor = new FuncionarioHorista (1010, "Pedro Silveira", "14/05/1978", "Adm" ,15.80);
        
        
        funcHor.setQtdeHorTrab(90);
        System.out.println("Registro            => " + funcHor.getRegistro());
        System.out.println("Nome Funcionario    => " + funcHor.getNome());
        System.out.println("Cargo               => " + funcHor.getCargo());
        System.out.println("Data Admissao       => " + funcHor.getDtAdmissao());
        System.out.println("Salário Bruto       => " + df.format(funcHor.calcSalBruto()));
        System.out.println("Desconto            => " + df.format(funcHor.calcDesconto()));
        System.out.println("Salário Liquido     => " + df.format(funcHor.calcSalLiquido()));
        
        
        FuncionarioMensalista funcMen = new FuncionarioMensalista (2020, "Jotape", "03/06/2001", "Sexologo" ,1518);
        
        funcMen.setNumSalMin(4);
        System.out.println("\n\nRegistro            => " + funcMen.getRegistro());
        System.out.println("Nome Funcionario    => " + funcMen.getNome());
        System.out.println("Cargo               => " + funcMen.getCargo());
        System.out.println("Data Admissao       => " + funcMen.getDtAdmissao());
        System.out.println("Salário Bruto       => " + df.format(funcMen.calcSalBruto()));
        System.out.println("Desconto            => " + df.format(funcMen.calcDesconto()));
        System.out.println("Salário Liquido     => " + df.format(funcMen.calcSalLiquido()));
        
        
        
    }
    
}
