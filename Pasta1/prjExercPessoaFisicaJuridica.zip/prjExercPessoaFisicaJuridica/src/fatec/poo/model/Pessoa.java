package fatec.poo.model;
/**
 *
 * @author 0030482321020
 */
abstract public class Pessoa {
    private String nome;
    private int anoInscricao;
    private double totalCompras;
    
    public Pessoa (String n, int ano){
        nome = n;
        anoInscricao = ano;
    }
    
    abstract public double calcBonus (int anoAtual);
    
    public void addCompras (double valComp){
        totalCompras += valComp;
    }
    
    public String getNome (){
        return (nome);
    }
    
    public int getAnoInscricao (){
        return (anoInscricao);
    }
    
    public double getTotalCompras (){
        return (totalCompras);
    }
}
