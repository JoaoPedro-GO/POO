package fatec.poo.model;
/**
 *
 * @author 0030482321020
 */
public class PessoaJuridica extends Pessoa{
    private String cgc;
    private double taxaIncentivo;
    
    public PessoaJuridica (String c, String n, int a){
        super(n, a);
        cgc = c;
    }

    public double calcBonus(int anoAtual) {
        return ((taxaIncentivo * getTotalCompras()) * (anoAtual - getAnoInscricao()));
    }
    
    public void setTaxaIncentivo (double x){
        taxaIncentivo = x;
    }
    
    public String getCgc (){
        return (cgc);
    }
    
    public double getTaxaIncentivo (){
        return (taxaIncentivo);
    }
}
