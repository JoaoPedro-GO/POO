import fatec.poo.model.PessoaJuridica;
import fatec.poo.model.PessoaFisica;
import java.text.DecimalFormat;
import java.util.Scanner;

/**
 *
 * @author 0030482321020
 */
public class Aplic {
    public static void main(String[] args) {
        Scanner entrada = new Scanner (System.in);
        DecimalFormat df = new DecimalFormat("#,##0.00");
        String nome, cpf, cgc;
        int ano;
        double compras;
        
        System.out.println("\n\tPessoa Fisica");
         System.out.print("Digite o nome: ");
         nome = entrada.next();
         System.out.print("Digite o cpf: ");
         cpf = entrada.next();
         System.out.print("Digite o ano de inscrição: ");
         ano = entrada.nextInt();
        PessoaFisica objPF = new PessoaFisica (cpf, nome, ano);
        
        do{
            System.out.println("Digite o valor da compra: ");
            compras = entrada.nextDouble();
            objPF.addCompras(compras);
        } while (compras > 0);
        
        objPF.setBase(10);
        System.out.println("\nNome: " + objPF.getNome());
        System.out.println("Cpf: " + objPF.getCpf());
        System.out.println("Ano Inscrição: " + objPF.getAnoInscricao());
        System.out.println("Total de Compras: " + df.format(objPF.getTotalCompras()));
        System.out.println("Valor Base: " + df.format(objPF.getBase()));
        System.out.println("Valor Bonus: " + df.format(objPF.calcBonus(2025)));
        
        System.out.println("\n\tPessoa Juridica");
         System.out.print("Digite o nome: ");
         nome = entrada.next();
         System.out.print("Digite o cgc: ");
         cgc = entrada.next();
         System.out.print("Digite o ano de inscrição: ");
         ano = entrada.nextInt();
        PessoaJuridica objPJ = new PessoaJuridica (cgc, nome, ano);
        
        do{
            System.out.println("Digite o valor da compra: ");
            compras = entrada.nextDouble();
            objPJ.addCompras(compras);
        } while (compras > 0);
        
        objPJ.setTaxaIncentivo(10);
        System.out.println("\nNome: " + objPJ.getNome());
        System.out.println("Cgc: " + objPJ.getCgc());
        System.out.println("Ano Inscrição: " + objPJ.getAnoInscricao());
        System.out.println("Total de Compras: " + df.format(objPJ.getTotalCompras()));
        System.out.println("Valor taxa de incentivo: " + df.format(objPJ.getTaxaIncentivo()));
        System.out.println("Valor Bonus: " + df.format(objPJ.calcBonus(2025)));
        
    
    }  
}
