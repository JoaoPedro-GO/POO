/**
 *
 * @author João Pedro
 */
public class Exemplo7 {
    public static void main(String[] args) {
        int tabNum[] = {4,8,7,23,17,23,87};
        int cont;
        
        for(cont=0;cont < tabNum.length;cont++){
            System.out.println("Conteudo de TabNum[" + cont + "] = " + tabNum[cont]);
        }
    }
}

