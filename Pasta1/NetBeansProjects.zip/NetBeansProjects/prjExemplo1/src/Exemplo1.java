/**
 *
 * @author João Pedro
 */
public class Exemplo1 {
    public static void main(String[] args) {
        int idade;
        double peso;
        char sexo;
        String nome;
        
        idade = 34;
        peso = 78.5;
        sexo = 'F';
        nome = "Ana Beatriz";
        
        System.out.println("Idade: " + idade);
        System.out.println("Peso: " + peso);
        System.out.println("Sexo: " + sexo);
        System.out.println("Nome: " + nome);
    }
}
