/**
 *
 * @author João Pedro
 */
public class Exemplo5 {
    public static void main(String[] args) {
        int cont = 1;
        
        System.out.println("\tTABUADA DO 7\n");
        do {
            System.out.println("7 * " + cont + " = " + cont * 7);
            cont ++;
        }while (cont <= 10);
    }
    
}
