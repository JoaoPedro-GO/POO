
import fatec.poo.model.Retangulo;

/**
 *
 * @author João Pedro
 */
public class Aplic {
    public static void main(String[] args) {
        //Definição do ponteiro para o objeto
        Retangulo objRet, objRet1;
        
        //Instanciação (alocação) de um objeto
        //a partir de uma classe
        objRet = new Retangulo();
        objRet1 = new Retangulo();
        
        objRet.setAltura(4.0);
        objRet.setBase (3.0);
        
        objRet1.setAltura(7.0);
        objRet1.setBase(5.0);
        
        
        System.out.println("Medida da área: " + objRet.calcArea());
        System.out.println("Medida do perimetro: " + objRet.calcPerimetro());
        System.out.println("Medida da Diagonal: " + objRet.calcDiagonal());
        System.out.println("Altura: " + objRet.getAltura());
        System.out.println("Base: " + objRet.getBase());
        
        
        System.out.println("\n\nMedida da área: " + objRet1.calcArea());
        System.out.println("Medida do perimetro: " + objRet1.calcPerimetro());
        System.out.println("Medida da Diagonal: " + objRet1.calcDiagonal());        
        System.out.println("Altura: " + objRet1.getAltura());
        System.out.println("Base: " + objRet1.getBase());
        
    }
    
}
