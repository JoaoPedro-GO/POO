
import fatec.poo.model.Retangulo;

/**
 *
 * @author João Pedro
 */
public class Aplic {
    public static void main(String[] args) {
        //Definição do ponteiro para o objeto
        Retangulo objRet;
        
        //Instanciação (alocação) de um objeto
        //a partir de uma classe
        objRet = new Retangulo();
        
        objRet.setAltura(5.0);
        objRet.setBase (8.0);
    }
    
}
