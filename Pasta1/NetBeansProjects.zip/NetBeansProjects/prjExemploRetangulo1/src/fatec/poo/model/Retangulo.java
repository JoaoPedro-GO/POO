package fatec.poo.model;
/**
 *
 * @author João Pedro
 */
public class Retangulo {
    private double altura, base;
    
    public void setAltura (double a){
        altura = a;
    }
    
    public void setBase (double b){
        base = b;
    }
    
    public double calcArea(){
        return(base*altura);
    }

    public double calcPerimetro(){
        return((2*base)+(2*altura)); 
    }
    
    public double getAltura(){
        return (altura);
    }
    
    public double getBase(){
        return (base);
    }
    
    public double calcDiagonal(){
        return (Math.sqrt((Math.pow(altura, 2))+(Math.pow(base, 2))));
    }
}
