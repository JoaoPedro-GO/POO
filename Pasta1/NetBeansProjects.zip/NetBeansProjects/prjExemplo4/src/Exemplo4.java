/**
 *
 * @author João Pedro
 */
public class Exemplo4 {
    public static void main(String[] args) {
        int cont = 1;
        
        System.out.println("\tTABUADA DO 7\n");
        while (cont <= 10) {
            System.out.println("7 * " + cont + " = " + cont * 7);
            cont ++;
        }
    }
    
}
